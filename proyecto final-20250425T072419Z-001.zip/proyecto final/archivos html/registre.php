<?php
$host = 'daw.ispedralbes.cat';
$usuario = 'a24ikematgar_incidencia';
$contrasena = ':8VBky{Uq9D^W-xk';
$base_datos = 'a24ikematgar_incidencia';

$conn = new mysqli($host, $usuario, $contrasena, $base_datos);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $departament = $_POST['departament'];
    $numero = $_POST['numero'];
    $descripcio = $_POST['descripcio'];
    $data = $_POST['data'];

    $stmt = $conn->prepare("INSERT INTO incidencias (departament, numero, descripcion, fecha) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $departament, $numero, $descripcio, $data);

    if ($stmt->execute()) {
        $mensaje = " Incidència guardada correctament.";
    } else {
        $mensaje = " Error al guardar la incidència: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registrar Incidència</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <h2>Registrar una nova incidència</h2>

  <?php if ($mensaje): ?>
    <p><?php echo $mensaje; ?></p>
  <?php endif; ?>

  <form method="POST" action="http://daw.inspedralbes.cat/form/action.php">
    <label for="departament">Departament:</label>
    <select name="departament" id="departament" required>
      <option value="">-- Selecciona --</option>
      <option value="Informàtica">Informàtica</option>
      <option value="Administració">Administració</option>
      <option value="RRHH">RRHH</option>
      <option value="Logística">Logística</option>
    </select> <br><br>

    <label for="numero">Número de PC:</label>
    <input type="text" name="numero" id="numero" required> <br><br>

    <label for="descripcio">Descripció de la incidència:</label>
    <textarea name="descripcio" id="descripcio" rows="2" required></textarea> <br><br>

    <label for="data">Data de l'incidència:</label>
    <input type="date" name="data" id="data" required> <br><br>

    <button type="submit">Registrar Incidència</button>
  </form>

</body>
</html>

